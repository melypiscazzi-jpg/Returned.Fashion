# Returned Fashion

A Pen created on CodePen.

Original URL: [https://codepen.io/fallyvkr-the-sans/pen/wBzyNpG](https://codepen.io/fallyvkr-the-sans/pen/wBzyNpG).

Swiss Secondhandshop